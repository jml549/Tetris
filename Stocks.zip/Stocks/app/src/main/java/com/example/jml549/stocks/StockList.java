package com.example.jml549.stocks;

public class StockList {
}
