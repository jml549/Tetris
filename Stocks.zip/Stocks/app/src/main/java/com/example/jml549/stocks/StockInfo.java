package com.example.jml549.stocks;

//Tutorial at: https://www.androidhive.info/2016/01/android-working-with-recycler-view/

public class StockInfo {
}
